﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPAtendimentoFila
{
    class Senhas
    {
        private Int32 proximoAtendimento;
        private Queue<Senha> filaSenhas;
        public Queue<Senha> FilaSenhas
        {
            get { return filaSenhas; }
        }

        public Int32 ProximoAtendimento
        {
            get { return proximoAtendimento; }
            set { proximoAtendimento = value; }
        }
        public Senhas(Int32 proximoAtendimento, Queue<Senha> filaSenhas)
        {
            this.proximoAtendimento = proximoAtendimento;
            this.filaSenhas = filaSenhas;
        }
        public Senhas(Int32 proximoAtendimento)
        {
            this.proximoAtendimento = proximoAtendimento;
        }
        public Senhas()
        {
            this.proximoAtendimento = 1;
            this.filaSenhas = new Queue<Senha>();
        }
        public override bool Equals(object obj)
        {
            Senhas p = (Senhas)obj;
            return this.proximoAtendimento.Equals(p.proximoAtendimento);
        }
        public void gerar()
        {
            filaSenhas.Enqueue(new Senha(this.proximoAtendimento++));
        }
    }
}
