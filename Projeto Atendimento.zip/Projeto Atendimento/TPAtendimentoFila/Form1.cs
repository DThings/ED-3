﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TPAtendimentoFila
{
    public partial class FormProjetoAtendimento : Form
    {
        
        private Guiches lisGuiches;
        private Guiche lisGuiche;
		private Senhas listSenhas;
        private Senha listSenha;

        public FormProjetoAtendimento()
        {
            InitializeComponent();

			lisGuiches = new Guiches();
			lisGuiche = new Guiche();
            listSenhas = new Senhas();
            listSenha = new Senha();
        }

        private void labelNumGuiches_Click(object sender, EventArgs e)
        {
            labelGuiche.Text = Convert.ToString(listSenhas.ProximoAtendimento);
        }

        private void buttonGerar_Click(object sender, EventArgs e)
        {
            listSenhas.gerar();
        }

        private void buttonListarSenhas_Click(object sender, EventArgs e)
        {
            listBoxSenhas.Items.Clear();

            foreach(Senha sen in listSenhas.FilaSenhas)
            {
                listBoxSenhas.Items.Add(sen.dadosParciais());
            }
        }

        private void buttonAdicionar_Click(object sender, EventArgs e)
        {
			lisGuiches.adicionar(new Guiche());
            labelNumGuiches.Text = Convert.ToString(lisGuiches.ListaGuiches.Count());
        }

        private void buttonListarAtendimentos_Click(object sender, EventArgs e)
        {
            listBoxAtendimento.Items.Clear();

            foreach (Guiche gui in lisGuiches.ListaGuiches)
            {
				foreach(Senha sen in gui.Atendimentos)
                listBoxAtendimento.Items.Add(sen.dadosCompletos());
            }
        }

        private void buttonChamar_Click(object sender, EventArgs e)
        {
			if (!lisGuiches.ListaGuiches[int.Parse(textBoxGuiche.Text) - 1].chamar(listSenhas.FilaSenhas))
               MessageBox.Show("Fila vazia");

        }

     
    }
}
